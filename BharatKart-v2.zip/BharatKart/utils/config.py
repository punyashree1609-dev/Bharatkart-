import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    APP_NAME: str = "BharatKart"
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///bharatkArt.db")
    AIVEN_KAFKA_ENABLED: bool = os.getenv("AIVEN_KAFKA_ENABLED", "false").lower() == "true"
    KAFKA_BOOTSTRAP_SERVERS: str = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "")
    AIVEN_OPENSEARCH_ENABLED: bool = os.getenv("AIVEN_OPENSEARCH_ENABLED", "false").lower() == "true"
    OPENSEARCH_URL: str = os.getenv("OPENSEARCH_URL", "")
    FREE_SHIPPING_THRESHOLD: float = 499.00
    STANDARD_SHIPPING_FEE: float = 49.00
    LOW_STOCK_THRESHOLD: int = 5


settings = Settings()

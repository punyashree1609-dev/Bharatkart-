import base64
from decimal import Decimal
from io import BytesIO
import uuid
from PIL import Image, ImageDraw


def format_inr(amount: Decimal | float | int) -> str:
    return f"₹{float(amount):,.2f}"


def generate_order_number() -> str:
    return f"BK-{uuid.uuid4().hex[:8].upper()}"


def generate_shop_code() -> str:
    return f"SHP-{uuid.uuid4().hex[:6].upper()}"


REAL_PRODUCT_PHOTOS: dict[str, str] = {
    # Electronics
    "BK-ELC-001": "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=800&q=85",
    "BK-ELC-002": "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=85",
    "BK-ELC-003": "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=800&q=85",
    "BK-ELC-004": "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=800&q=85",
    "BK-ELC-005": "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=800&q=85",
    # Home & Kitchen
    "BK-HOM-001": "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=85",
    "BK-HOM-002": "https://images.unsplash.com/photo-1610701596007-11502861dcfa?auto=format&fit=crop&w=800&q=85",
    "BK-HOM-003": "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=800&q=85",
    "BK-HOM-004": "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=85",
    "BK-HOM-005": "https://images.unsplash.com/photo-1585515320310-259814833e62?auto=format&fit=crop&w=800&q=85",
    # Fashion
    "BK-FSH-001": "https://images.unsplash.com/photo-1601924994987-69e26d50dc26?auto=format&fit=crop&w=800&q=85",
    "BK-FSH-002": "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=85",
    "BK-FSH-003": "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=85",
    "BK-FSH-004": "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=800&q=85",
    "BK-FSH-005": "https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=800&q=85",
    # Groceries
    "BK-GRO-001": "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&w=800&q=85",
    "BK-GRO-002": "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=800&q=85",
    "BK-GRO-003": "https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?auto=format&fit=crop&w=800&q=85",
    "BK-GRO-004": "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=85",
    "BK-GRO-005": "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=800&q=85",
    # Personal Care
    "BK-PRC-001": "https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?auto=format&fit=crop&w=800&q=85",
    "BK-PRC-002": "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=85",
    "BK-PRC-003": "https://images.unsplash.com/photo-1617897903246-719242758050?auto=format&fit=crop&w=800&q=85",
    "BK-PRC-004": "https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&w=800&q=85",
    "BK-PRC-005": "https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?auto=format&fit=crop&w=800&q=85",
}


def get_product_photo_url(sku: str) -> str:
    return REAL_PRODUCT_PHOTOS.get(
        sku,
        "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=85",
    )


def get_offline_fallback_png(sku: str, category: str) -> str:
    """Offline backup PNG only used if the browser has no internet access to Unsplash."""
    W, H = 640, 420
    img = Image.new("RGB", (W, H), (243, 236, 225))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle([24, 24, W - 24, H - 24], radius=16, fill=(255, 255, 255), outline=(223, 211, 195), width=3)
    draw.text((48, 48), f"{category.upper()} · {sku}", fill=(74, 25, 44))
    draw.text((48, 200), "Connect to internet to load HD product photo", fill=(89, 82, 75))
    buf = BytesIO()
    img.save(buf, format="PNG")
    return f"data:image/png;base64,{base64.b64encode(buf.getvalue()).decode('ascii')}"


def get_service_health(db_ok: bool, pending_outbox: int) -> list[dict]:
    from utils.config import settings

    is_pg = settings.DATABASE_URL.startswith("postgresql")
    return [
        {
            "service": "Primary Datastore",
            "engine": "Aiven PostgreSQL" if is_pg else "Local SQLite (Aiven PG Ready)",
            "status": "Connected" if db_ok else "Error",
            "active": db_ok,
            "note": "ACID transactions & conditional stock locking active.",
        },
        {
            "service": "Event Streaming",
            "engine": "Aiven Apache Kafka",
            "status": "Connected" if (settings.AIVEN_KAFKA_ENABLED and settings.KAFKA_BOOTSTRAP_SERVERS) else "Standby (Outbox Active)",
            "active": bool(settings.AIVEN_KAFKA_ENABLED and settings.KAFKA_BOOTSTRAP_SERVERS),
            "note": f"{pending_outbox} event(s) persisted in transactional outbox table.",
        },
        {
            "service": "Search Engine",
            "engine": "Aiven OpenSearch",
            "status": "Connected" if (settings.AIVEN_OPENSEARCH_ENABLED and settings.OPENSEARCH_URL) else "Standby (SQL Indexed Search)",
            "active": bool(settings.AIVEN_OPENSEARCH_ENABLED and settings.OPENSEARCH_URL),
            "note": "Indexed multi-field SQL catalogue search active locally.",
        },
    ]
